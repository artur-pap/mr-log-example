package ru.apapikyan.learn.bigdata.mapreds.seqfile;

public class test {

}
